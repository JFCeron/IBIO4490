The ground truth contains the following information:
image-name Leye-x Leye-y Reye-x Reye-y nose-x nose-y mouth-x mouth-y


The images and the ground truth were collected and organized by  Michael Fink while visiting the Caltech Vision Group . Rob Fergus provided a script for harvesting images from Google.